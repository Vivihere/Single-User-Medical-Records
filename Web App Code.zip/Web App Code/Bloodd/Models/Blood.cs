﻿using System;
namespace Bloodd.Models
{
    public class Blood
    {
        public int Id { get; set; }
        public string DateCreate { get; set; }
        public string DateExam { get; set; }
        public string DateResults { get; set; }
        public string Description { get; set; }
        public float Hemoglobin { get; set; }
        public float Hematocrit { get; set; }
        public int CountWhiteB { get; set; }
        public float CountRedB { get; set; }
    }
}