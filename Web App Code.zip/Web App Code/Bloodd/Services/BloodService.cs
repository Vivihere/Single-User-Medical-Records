﻿using Bloodd.Models;
using System;
using System.Collections.Generic;
using System.Linq;
namespace Bloodd.Services
{
    public class BloodService
    {
        private static List<Blood> bloods = new List<Blood>();
        private static int Count = 1;
        static BloodService()
        {
            /*
                Blood blood = new Blood
                {
                    Id = Count,
                    DateCreate = "",
                    DateExam = "",
                    DateResults = "",
                    Description = "",
                    Hemoglobin = 0,
                    Hematocrit = 0,
                    CountWhiteB = 0,
                    CountRedB = 0
                };
                bloods.Add(blood);
            */
        }
        public List<Blood> GetAll()
        {
            return bloods;
        }
        public Blood GetById(int id)
        {
            return bloods.Where(user => user.Id == id).FirstOrDefault();
        }
        public Blood Create(Blood blood)
        {
            blood.Id = ++Count;
            bloods.Add(blood);
            return blood;
        }
        public void Update(int id, Blood user)
        {
            Blood found = bloods.Where(n => n.Id == id).FirstOrDefault();

            found.DateCreate = user.DateCreate;
            found.DateExam = user.DateExam;
            found.DateResults = user.DateResults;
            found.Description = user.Description;
            found.Hemoglobin = user.Hemoglobin;
            found.Hematocrit = user.Hematocrit;
            found.CountWhiteB = user.CountWhiteB;
            found.CountRedB = user.CountRedB;
        }
        public void Delete(int id)
        {
            bloods.RemoveAll(n => n.Id == id);
        }
    }
}