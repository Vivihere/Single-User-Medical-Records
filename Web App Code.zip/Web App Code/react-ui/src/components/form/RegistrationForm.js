import React from 'react';
import { Button, Form, FormGroup, Input, Label } from 'reactstrap';
import { USERS_API_URL } from '../../constants';
class RegistrationForm extends React.Component {
    state = {
        id: 0,
        dateCreate: '',
        dateExam: '',
        dateResults: '',
        description: '',
        hemoglobin: 0,
        hematocrit: 0,
        countWhiteB: 0,
        countRedB: 0
    }
    componentDidMount() {
        if (this.props.user) {
            const { id, dateCreate, dateExam, dateResults,  description, hemoglobin, hematocrit, countWhiteB, countRedB} = this.props.user
            this.setState({ id, dateCreate, dateExam, dateResults, description, hemoglobin, hematocrit, countWhiteB, countRedB});
        }
    }
    onChange = e => {
        this.setState({ [e.target.name]: e.target.value })
    }
    submitNew = e => {
        e.preventDefault();
        fetch(`${USERS_API_URL}`, {
            method: 'post',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                dateCreate: this.state.dateCreate,
                dateExam: this.state.dateExam,
                dateResults: this.state.dateResults,
                description: this.state.description,
                hemoglobin: parseFloat(this.state.hemoglobin),
                hematocrit: parseFloat(this.state.hematocrit),
                countWhiteB: parseInt(this.state.countWhiteB),
                countRedB: parseFloat(this.state.countRedB)
            })
        })
            .then(res => res.json())
            .then(user => {
                this.props.addUserToState(user);
                this.props.toggle();
            })
            .catch(err => console.log(err));
    }
    submitEdit = e => {
        e.preventDefault();
        fetch(`${USERS_API_URL}/${this.state.id}`, {
            method: 'put',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                dateCreate: this.state.dateCreate,
                dateExam: this.state.dateExam,
                dateResults: this.state.dateResults,
                description: this.state.description,
                hemoglobin: parseFloat(this.state.hemoglobin),
                hematocrit: parseFloat(this.state.hematocrit),
                countWhiteB: parseInt(this.state.countWhiteB),
                countRedB: parseFloat(this.state.countRedB)
            })
        })
            .then(() => {
                this.props.toggle();
                this.props.updateUserIntoState(this.state.id);
            })
            .catch(err => console.log(err));
    }
    render() {
        return <Form onSubmit={this.props.user ? this.submitEdit : this.submitNew}>
            <FormGroup>
                <Label for="dateCreate">Date Created:</Label>
                <Input type="date" name="dateCreate" onChange={this.onChange} value={this.state.dateCreate === '' ? '' : this.state.dateCreate} />
            </FormGroup>
            <FormGroup>
                <Label for="dateExam">Date of Exam:</Label>
                <Input type="date" name="dateExam" onChange={this.onChange} value={this.state.dateExam === '' ? '' : this.state.dateExam} />
            </FormGroup>
            <FormGroup>
                <Label for="dateResults">Date of Results:</Label>
                <Input type="date" name="dateResults" onChange={this.onChange} value={this.state.dateResults === '' ? '' : this.state.dateResults} />
            </FormGroup>
            <FormGroup>
                <Label for="description">Description:</Label>
                <Input type="text" name="description" onChange={this.onChange} value={this.state.description === '' ? '' : this.state.description} />
            </FormGroup>
            <FormGroup>
                <Label for="hemoglobin">Hemoglobin Count:</Label>
                <Input type="number" name="hemoglobin" min="0" step="0.01" onChange={this.onChange} value={this.state.hemoglobin === null ? '' : this.state.hemoglobin} />
            </FormGroup>
            <FormGroup>
                <Label for="hematocrit">Hematocrit Count:</Label>
                <Input type="number" name="hematocrit" min="0" step="0.01" onChange={this.onChange} value={this.state.hematocrit === '' ? '' : this.state.hematocrit} />
            </FormGroup>
            <FormGroup>
                <Label for="countWhiteB">White Blood Cell Count:</Label>
                <Input type="number" name="countWhiteB" min="0" step="0.01" onChange={this.onChange} value={this.state.countWhiteB === '' ? '' : this.state.countWhiteB} />
            </FormGroup>
            <FormGroup>
                <Label for="countRedB">Red Blood Cell Count:</Label>
                <Input type="number" name="countRedB" min="0" step="0.01" onChange={this.onChange} value={this.state.countRedB === '' ? '' : this.state.countRedB} />
            </FormGroup>
            <Button>Confirm</Button>
        </Form>;
    }
}
export default RegistrationForm;