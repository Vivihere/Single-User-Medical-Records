import React, { Component } from 'react'; 
import {
    Navbar,
    NavbarBrand,
    NavbarToggler,
    Collapse,
    Nav,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem
} from 'reactstrap'; 
class AppHeader extends Component { 
    state = { 
        isOpen: false
    };
    toggle = this.toggle.bind(this); 
    toggle() { 
        this.setState({
            isOpen: !this.state.isOpen
        })
    }
    render() { 
        return <Navbar color="info" dark expand="md">
            <NavbarBrand href="/">
                <img src="http://www.clipartbest.com/cliparts/4c9/apj/4c9apjGzi.png" width="80" height="80" className="d-inline-block align-top" alt="" />
                &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                View Your BloodWork!
            </NavbarBrand>
            <NavbarToggler onClick={this.toggle} />
            <Collapse isOpen={this.state.isOpen} navbar>
                <Nav className="ml-auto" navbar>
                    <UncontrolledDropdown nav inNavbar>
                        <DropdownToggle nav caret>
                            Account
                        </DropdownToggle>
                        <DropdownMenu right>
                            <DropdownItem href="javascript:alert('Dosent work! You may never log out!!');">Log Out</DropdownItem>
                        </DropdownMenu>
                    </UncontrolledDropdown>
                </Nav>
            </Collapse>
        </Navbar>;
    }
}
export default AppHeader; 